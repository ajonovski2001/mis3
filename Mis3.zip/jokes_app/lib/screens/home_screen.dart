import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '/screens/favorites_screen.dart'; // Make sure the file path is correct
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String jokeOfTheDay = "";
  List<String> favoriteJokes = [];

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

 
  Future<void> fetchJokeOfTheDay() async {
    final response = await http.get(Uri.parse('https://official-joke-api.appspot.com/random_joke'));

    if (response.statusCode == 200) {
      final jokeData = json.decode(response.body);
      setState(() {
        jokeOfTheDay = "${jokeData['setup']} - ${jokeData['punchline']}";
      });
    } else {
      throw Exception('Failed to load joke');
    }
  }


  void toggleFavorite(String joke) {
    setState(() {
      if (favoriteJokes.contains(joke)) {
        favoriteJokes.remove(joke);
      } else {
        favoriteJokes.add(joke);
      }
    });
  }

  
  Future<List<String>> fetchJokes(String category) async {
    final response = await http.get(Uri.parse('https://official-joke-api.appspot.com/jokes/$category/ten'));

    if (response.statusCode == 200) {
      final jokeData = json.decode(response.body);
      return List<String>.from(jokeData.map((joke) => "${joke['setup']} - ${joke['punchline']}"));
    } else {
      throw Exception('Failed to load jokes');
    }
  }

  
  @override
  void initState() {
    super.initState();
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      
      print('Message received: ${message.notification?.title}');
    });
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    
    _initializeLocalNotifications();
  }

  Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    
    print("Handling background message: ${message.messageId}");
  }

  // Initialize local notifications
  void _initializeLocalNotifications() {
    const AndroidInitializationSettings androidInitializationSettings = AndroidInitializationSettings('app_icon');
    final InitializationSettings initializationSettings = InitializationSettings(
      android: androidInitializationSettings,
    );
    flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

 
  Future<void> _scheduleDailyReminder() async {
    final time = Time(8, 0, 0); 
    const AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'daily_reminder_channel', 'Daily Joke Reminder',
      channelDescription: 'Reminds user to check the joke of the day.',
      importance: Importance.high,
      priority: Priority.high,
      ticker: 'ticker',
    );
    const NotificationDetails platformChannelSpecifics = NotificationDetails(android: androidPlatformChannelSpecifics);

    await flutterLocalNotificationsPlugin.showDailyAtTime(
      0,
      'Check Joke of the Day!',
      'Don\'t forget to check your joke of the day.',
      time,
      platformChannelSpecifics,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Jokes App"),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              // Trigger local notification reminder manually
              _scheduleDailyReminder();
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: fetchJokeOfTheDay,
              child: const Text("Get Joke of the Day"),
            ),
            if (jokeOfTheDay.isNotEmpty) ...[
              const SizedBox(height: 20),
              Text(
                jokeOfTheDay,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () => toggleFavorite(jokeOfTheDay),
                child: Text(favoriteJokes.contains(jokeOfTheDay) ? "Remove from Favorites" : "Add to Favorites"),
              ),
            ],
            const SizedBox(height: 30),
            const Text("Select a Joke Category:", style: TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    List<String> dadJokes = await fetchJokes("dad");
                    showJokesDialog(dadJokes);
                  },
                  child: const Text("Dad Jokes"),
                ),
                ElevatedButton(
                  onPressed: () async {
                    List<String> programmingJokes = await fetchJokes("programming");
                    showJokesDialog(programmingJokes);
                  },
                  child: const Text("Programming Jokes"),
                ),
                ElevatedButton(
                  onPressed: () async {
                    List<String> generalJokes = await fetchJokes("general");
                    showJokesDialog(generalJokes);
                  },
                  child: const Text("General Jokes"),
                ),
                ElevatedButton(
                  onPressed: () async {
                    List<String> knockKnockJokes = await fetchJokes("knock-knock");
                    showJokesDialog(knockKnockJokes);
                  },
                  child: const Text("Knock-Knock Jokes"),
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => FavoritesScreen(favoriteJokes: favoriteJokes)),
          );
        },
        child: const Icon(Icons.favorite),
        tooltip: 'Go to Favorites',
      ),
    );
  }

  void showJokesDialog(List<String> jokes) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Jokes"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: jokes.map((joke) {
              return ListTile(
                title: Text(joke),
                trailing: IconButton(
                  icon: Icon(
                    favoriteJokes.contains(joke) ? Icons.favorite : Icons.favorite_border,
                    color: favoriteJokes.contains(joke) ? Colors.red : null,
                  ),
                  onPressed: () => toggleFavorite(joke),
                ),
              );
            }).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close"),
            ),
          ],
        );
      },
    );
  }
}