class JokeTypeModel {
  final String type;

  JokeTypeModel({required this.type});

  factory JokeTypeModel.fromJson(Map<String, dynamic> json) {
    return JokeTypeModel(
      type: json['type'],
    );
  }
}
